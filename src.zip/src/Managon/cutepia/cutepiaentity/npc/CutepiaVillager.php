<?php

namespace Managon\cutepia\cutepiaentity\npc;

use Managon\cutepia\Cutepia;
use Managon\cutepia\CutepiaEntity;

class CutepiaVillager extends CutepiaNPC
{

}