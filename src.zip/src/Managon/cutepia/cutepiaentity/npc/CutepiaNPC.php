<?php

namespace Managon\cutepia\cutepiaentity\npc;

use Managon\cutepia\CutepiaEntity;

abstract class CutepiaNPC extends CutepiaEntity
{
	
}