<?php

namespace Managon\cutepia\cutepiaentity\monsters;

use Managon\cutepia\Cutepia;
use Managon\cutepia\CutepiaEntity;

abstract class CutepiaMonster extends CutepiaEntity
{

}