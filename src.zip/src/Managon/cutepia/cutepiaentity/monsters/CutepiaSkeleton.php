<?php

namespace Managon\cutepia\cutepiaentity\monsters;

use Managon\cutepia\Cutepia;
use Managon\cutepia\CutepiaEntity;
use Managon\cutepia\cutepiaentity\monsters\CutepiaMonster;

class CutepiaSkeleton extends CutepiaMonster
{

}