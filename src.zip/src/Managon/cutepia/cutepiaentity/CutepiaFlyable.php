<?php

namespace Managon\cutepia\cutepiaentity;


interface CutepiaFlyable
{
	
}