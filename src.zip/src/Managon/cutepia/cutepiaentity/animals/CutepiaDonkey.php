<?php

namespace Managon\cutepia\cutepiaentity\animals;

use Managon\cutepia\Cutepia;
use Managon\cutepia\CutepiaEntity;
use Managon\cutepia\cutepiaentity\animals\CutepiaAnimal;
use Managon\cutepia\cutepiaentity\CutepiaRideable;

class CutepiaDonkey extends CutepiaAnimal implements CutepiaRideable
{
}