<?php

namespace Managon\cutepia\cutepiaentity\animals;

use Managon\cutepia\Cutepia;
use Managon\cutepia\CutepiaEntity;
use Managon\cutepia\cutepiaentity\animals\CutepiaAnimal;
use Managon\cutepia\cutepiaentity\CutepiaFlyable;

class CutepiaBat extends CutepiaAnimal implements CutepiaFlyable
{
}
