<?php

namespace Managon\cutepia\cutepiaentity\animals;

use Managon\cutepia\CutepiaEntity;

abstract class CutepiaAnimal extends CutepiaEntity
{
	
}