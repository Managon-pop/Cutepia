<?php

namespace Managon\cutepia\cutepiaentity\animals;

use Managon\cutepia\Cutepia;
use Managon\cutepia\CutepiaEntity;
use Managon\cutepia\cutepiaentity\animals\CutepiaAnimal;

class CutepiaSkeletonHorse extends CutepiaAnimal
{
}